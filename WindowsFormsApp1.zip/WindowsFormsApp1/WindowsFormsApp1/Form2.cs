﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form2: Form
    {
        String connectionString = @"Data Source=DESKTOP-G0GM86R;Initial Catalog=Login;Integrated Security=True;Encrypt=False";
        public Form2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtun.Text == "" || txtpw.Text == "")
            {
                MessageBox.Show("Please fill mandatory fields");
            }
            else if (txtpw.Text != txtcnfrmpw.Text)
            {
                MessageBox.Show("Passwords Do Not match!");
            }
            else if (txtpw.Text.Length < 8)
            {
                MessageBox.Show("Passwords should have atleast 8 characters");
            }
            else
            {
                using (SqlConnection sqlcon = new SqlConnection(connectionString))
                {
                    sqlcon.Open();
                    // **Check if username already exists**
                    SqlCommand checkUserCmd = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Username = @Username", sqlcon);
                    checkUserCmd.Parameters.AddWithValue("@Username", txtun.Text.Trim());
                    int userExists = (int)checkUserCmd.ExecuteScalar();

                    if (userExists > 0)
                    {
                        MessageBox.Show("Username already exists. Please choose another username.");
                    }
                    else
                    {
                        SqlCommand sqlcmd = new SqlCommand("useradd", sqlcon);
                        sqlcmd.CommandType = CommandType.StoredProcedure;
                        sqlcmd.Parameters.AddWithValue("@Username", txtun.Text.Trim());
                        sqlcmd.Parameters.AddWithValue("@Password", txtpw.Text.Trim());
                        sqlcmd.ExecuteNonQuery();
                        MessageBox.Show("Sign Up Successful");
                        clear();
                    }
                }
            }
        }
        void clear()
        {
            txtun.Text = txtpw.Text = txtcnfrmpw.Text= "";
        }
    }
}
